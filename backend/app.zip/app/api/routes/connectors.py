from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from app.services.connectors.service import (
    connector_service,
)


router = APIRouter(
    prefix="/connectors",
    tags=["Connectors"],
)


# ============================================================
# REQUEST MODELS
# ============================================================


class ConnectorCredentials(BaseModel):
    """
    Credentials supplied when connecting an external system.

    The dictionary approach keeps this generic because
    different connectors require different credentials.
    """

    credentials: dict[str, Any] = Field(
        default_factory=dict
    )


class FetchRequest(BaseModel):
    """
    Request for fetching data from an external connector.
    """

    credentials: dict[str, Any] = Field(
        default_factory=dict
    )

    options: dict[str, Any] = Field(
        default_factory=dict
    )


class NormalizeRequest(BaseModel):
    """
    Request for normalizing external connector records
    into the Company OS format.
    """

    records: list[dict[str, Any]] = Field(
        default_factory=list
    )


# ============================================================
# LIST CONNECTORS
# ============================================================


@router.get("")
def list_connectors():
    """
    List all registered external connectors.
    """

    try:

        return {
            "connectors": connector_service.list_registered_connectors()
        }

    except Exception as exc:

        raise HTTPException(
            status_code=500,
            detail=str(exc),
        ) from exc


# ============================================================
# CONNECT
# ============================================================


@router.post("/{connector_name}/connect")
def connect_connector(
    connector_name: str,
    request: ConnectorCredentials,
):
    """
    Connect to an external system.
    """

    try:

        result = connector_service.connect(
            connector_name,
            request.credentials,
        )

        return {
            "connector": connector_name,
            **result,
        }

    except ValueError as exc:

        raise HTTPException(
            status_code=400,
            detail=str(exc),
        ) from exc

    except Exception as exc:

        raise HTTPException(
            status_code=500,
            detail=str(exc),
        ) from exc


# ============================================================
# TEST CONNECTION
# ============================================================


@router.post("/{connector_name}/test")
def test_connector(
    connector_name: str,
    request: ConnectorCredentials | None = None,
):
    """
    Test a connector connection.
    """

    try:

        credentials = (
            request.credentials
            if request
            else None
        )

        result = connector_service.test_connection(
            connector_name,
            credentials,
        )

        return {
            "connector": connector_name,
            **result,
        }

    except ValueError as exc:

        raise HTTPException(
            status_code=400,
            detail=str(exc),
        ) from exc

    except Exception as exc:

        raise HTTPException(
            status_code=500,
            detail=str(exc),
        ) from exc


# ============================================================
# FETCH EXTERNAL DATA
# ============================================================


@router.post("/{connector_name}/fetch")
def fetch_connector_data(
    connector_name: str,
    request: FetchRequest,
):
    """
    Fetch records from an external connector.

    The options dictionary is connector-specific.

    Example:

    {
        "credentials": {
            "token": "..."
        },
        "options": {
            "limit": 50
        }
    }
    """

    try:

        records = connector_service.fetch(
            connector_name,
            request.credentials,
            **request.options,
        )

        return {
            "connector": connector_name,
            "count": len(records),
            "records": records,
        }

    except ValueError as exc:

        raise HTTPException(
            status_code=404,
            detail=str(exc),
        ) from exc

    except RuntimeError as exc:

        raise HTTPException(
            status_code=400,
            detail=str(exc),
        ) from exc

    except Exception as exc:

        raise HTTPException(
            status_code=500,
            detail=str(exc),
        ) from exc


# ============================================================
# NORMALIZE EXTERNAL DATA
# ============================================================


@router.post("/{connector_name}/normalize")
def normalize_connector_data(
    connector_name: str,
    request: NormalizeRequest,
):
    """
    Normalize external records into the Company OS
    internal representation.
    """

    try:

        records = connector_service.normalize(
            connector_name,
            request.records,
        )

        return {
            "connector": connector_name,
            "count": len(records),
            "records": records,
        }

    except ValueError as exc:

        raise HTTPException(
            status_code=404,
            detail=str(exc),
        ) from exc

    except Exception as exc:

        raise HTTPException(
            status_code=500,
            detail=str(exc),
        ) from exc


# ============================================================
# DISCONNECT
# ============================================================


@router.delete("/{connector_name}")
def disconnect_connector(
    connector_name: str,
):
    """
    Disconnect a connector.
    """

    try:

        result = connector_service.disconnect(
            connector_name
        )

        return {
            "connector": connector_name,
            **result,
        }

    except ValueError as exc:

        raise HTTPException(
            status_code=404,
            detail=str(exc),
        ) from exc

    except Exception as exc:

        raise HTTPException(
            status_code=500,
            detail=str(exc),
        ) from exc
